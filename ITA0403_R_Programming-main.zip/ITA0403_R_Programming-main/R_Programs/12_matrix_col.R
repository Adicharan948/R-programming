A<-c(1,2,3)
B<-c(4,5,6)
C<-c(7,8,9)
mat<-cbind(A,B,C)
mat