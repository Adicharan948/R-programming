movie_data = read.csv(file="D:/folders/R/CSV!.csv", header=TRUE, sep=",")
print("Content of the .csv file:")
print(movie_data)